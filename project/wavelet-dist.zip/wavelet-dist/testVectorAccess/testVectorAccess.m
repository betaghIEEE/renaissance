#import <Foundation/Foundation.h>
#import <oc-matrix/matrixType.h> 
#import <oc-matrix/myVector.h>

int main (int argc, const char * argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	
    // insert code here...
    NSLog(@"Hello, World!");
	matrixType *myMat = [[matrixType init] alloc];
	myVector *myVec = [[myVector init] alloc];
	[myMat allocateRows:5 columns:5];
	[myVec allocateWith:5];
	double temp;
	int i , j;
	for ( i = 0; i < 5; i++)
		for ( j = 0; j < 5; j++)
			[myMat matrix][i][j] = i * j;
	for ( i = 0; i < 5; i++)
		for ( j = 0; j < 5; j++)
		{
			temp = ([myMat matrix][i][j]);
			printf ("Value at i= %d and j = %d is %f \n", i, j, temp);
		}
	for ( i = 0; i < 5; i++)
		[myVec vector][i] = i;
	for ( i= 0; i < 5; i++)
	{
		temp = ([myVec vector][i]);
		printf ("Value at i= %d  is %f \n", i, temp);
	}
	
		
    [pool release];
    return 0;
}
