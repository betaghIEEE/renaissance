//
//  xformpsi.m
//  oc-matrix
//
//  Created by Daniel Beatty on 4/1/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import "xformpsi.h"


@implementation xformpsi
-(id) init 
{
	S = [[matrixType init] alloc];
	T = [[matrixType init] alloc];
	ha = [[myVector init] alloc];
	hd = [[myVector init] alloc];
	xTemp = [[myVector init] alloc];
	xTemp2 = [[myVector init] alloc];
	yTemp = [[myVector init] alloc];
	yTemp2 = [[myVector init] alloc];
	NSLog (@"Initialized the PsiN Xform");
	[super init];
}

-(void) getSstats: (struct quadnode *) r
{
    double sum = 0.0;
    double sum2 = 0.0;
	double max = 0.0;
    double min = pow (10.0,37.0);
    int i, j;
	max = [S getMaxWithIn:r->xul lRows:r->xll lCols:r->yul rCols: r->yur ];
	min = [S getMinWithIn:r->xul lRows:r->xll lCols:r->yul rCols: r->yur ];
	sum = [S getL1EnergyWithIn:r->xul lRows:r->xll lCols:r->yul rCols: r->yur ];
	sum = [S getEnergyWithIn:r->xul lRows:r->xll lCols:r->yul rCols: r->yur ];
            r->max = max;
    r->min = min;
    r->L1energy = sum;
    r->L2energy = sum2;
    
}


-(void) setAnode: (struct quadnode *)a withNode: (struct quadnode *) r;
{
    if(((r->rows % 2) == 0) & ((r->cols % 2) ==0))
    {
        int rows = (r->rows)/2;
        int cols = (r->cols)/2;
        a->rows = rows;
        a->cols = cols;
        a->xul = r->xul;
        a->xll = r->xul + rows - 1;
        a->xur = r->xur;
        a->xlr = r->xur + rows - 1;
        a->yul = r->yul;
        a->yur = r->yul + cols - 1;
        a->yll = r->yll;
        a->ylr = r->yll + cols - 1;
        a->isnotnull = 1;
        a->myid = r->myid * 4 + 1;
        a->epsilon = r->epsilon;
		
    } else a->isnotnull = 0;
    
}

-(void) setVnode: (struct quadnode *)a withNode: (struct quadnode *) r;
{
    if(((r->rows % 2) == 0) & ((r->cols % 2) ==0))
    {
        int rows = (r->rows)/2;
        int cols = (r->cols)/2;
        a->rows = rows;
        a->cols = cols;
        a->xul = r->xul;
        a->xll = r->xul + rows - 1;
        a->xur = r->xur;
        a->xlr = r->xur + rows - 1;
        a->yul = r->yul + cols;
        a->yll = r->yul + cols;
        a->yur = r->yur;
        a->ylr = r->ylr;
        a->isnotnull = 1;
        a->myid = r->myid * 4 + 2;
        a->epsilon = r->epsilon;
    } else a->isnotnull = 0;
}

-(void) setHnode: (struct quadnode *)a withNode: (struct quadnode *) r;
{
    if(((r->rows % 2) == 0) & ((r->cols % 2) ==0))
    {
        int rows = (r->rows)/2;
        int cols = (r->cols)/2;
        a->rows = rows;
        a->cols = cols;
        
        a->xul = r->xul + rows;
        a->xll = r->xll;
        a->xur = r->xur + rows;
        a->xlr = r->xlr;
        a->yul = r->yul;
        a->yll = r->yll;
        a->yur = r->yul + cols - 1;
        a->ylr = r->yll + cols - 1;
        a->isnotnull = 1;
        a->myid = r->myid * 4 + 3;
        a->epsilon = r->epsilon;
    } else a->isnotnull = 0;
}

-(void) setDnode: (struct quadnode *)a withNode: (struct quadnode *) r;
{
    if(((r->rows % 2) == 0) & ((r->cols % 2) ==0))
    {
        int rows = (r->rows)/2;
        int cols = (r->cols)/2;
        a->rows = rows;
        a->cols = cols;
        
        a->xul = r->xul + rows;
        a->xll = r->xll;
        a->xur = r->xur + rows;
        a->xlr = r->xlr;
        a->yul = r->yul + cols;
        a->yll = r->yul + cols;
        a->yur = r->yur;
        a->ylr = r->ylr;
        a->isnotnull = 3;
        a->myid = r->myid * 4 + 4;
        a->epsilon = r->epsilon;
    } else a->isnotnull = 0;
}



-(void) rowWXform
{
    
    int k, l, n, i;
	
    int o = [ha size];
    int p = [hd size];
	
    int s2 = [S m_cols] /2;
    int s = [S m_cols];
    int rows = [S m_rows];
	
	xTemp = [[myVector init] alloc];
	xTemp2 = [[myVector init] alloc];
	
	[xTemp allocateWith:s];
	[xTemp2 allocateWith:s];
	
	NSLog (@"Begining Row x form");
	
	printf ("Rows %d s %d s2 %d ", rows, s, s2);
    for ( i = 0; i < rows; i++){
        for ( k = 0; k < s; k++)
        {
			printf (" %d ", k);
            [xTemp vector][k] = 0.0;
            [xTemp2 vector][k] = 0.0;
        }    
		NSLog (@"Initializaed xTerm");
        for (k =0; k < s; k++)
            for ( l = 0; l < o; l++)
            {
                n = k -l;
                if ( (n >= 0) && ( n <  s)) {
                    [xTemp vector][k] += [S matrix][i][n] * [ha vector][l];
                    [xTemp2 vector][k] += [S matrix][i][n] * [hd vector][l];
                }
                
            }
				
                for ( k = 0; k < s2; k++)
                {
                    [S matrix][i][k] = [xTemp vector][2*k + 1];
                    [S matrix][i][k+s2] = [xTemp2 vector][2*k+1];
                }        
		
    }
		[xTemp release];
		[xTemp2 release];
}


-(void) colWXform
{
    
    
    int k, l, n, j;
    int o = [ha size];
    int p = [hd size];
	
    int s2 = [S m_rows] /2;
    int s = [S m_rows];
    int cols = [S m_cols];
	
	yTemp = [[myVector init] alloc];
	yTemp2 = [[myVector init] alloc];
	[yTemp allocateWith:s];
	[yTemp2 allocateWith:s];
		
    for ( j = 0; j < cols; j++) { 
        for ( k = 0; k < s; k++)
        {
            [yTemp vector][k] = 0.0;
            [yTemp2 vector][k] = 0.0;
        }
        for ( k = 0; k < s; k++)
            for ( l = 0; l < o; l++)
            {
                n = k -l;
				if ( ( n >= 0) && ( n < s)) {
                    [yTemp vector][k] += [S matrix][n][j] * [ha vector][l];
                    [yTemp vector][k] += [S matrix][n][j] * [hd vector][l];

                }
            }
                
			//	for ( k = 0; k < s2; k++) {
			//		[S matrix][k][j] = [yTemp vector][2*k + 1];
			//		[S matrix][k +s2][j] = [yTemp2 vector][2*k+1];
					
			//	}
    }
		 [yTemp release];
		 [yTemp2 release];
	
		
}

-(void) WXform
{
	int index;
	
    int length = resolution;
    int length4 = resolution/4 + 1;
	//S = [[matrixType init] alloc];
	//T = [[matrixType init] alloc];
	ha = [[myVector init] alloc];
	hd = [[myVector init] alloc];
	
	NSLog (@"Beggining Transform");	
    for ( index = 0; index < length; index++)
    {
        [self rowWXform];
        [self colWXform];
		NSLog (@"Next Batch");
    }
    
}


-(BOOL) WXformWithResolution: (int) res
{
	resolution = res;
	[self WXform];
}

-(matrixType *) xFormMatrix: (matrixType *) A withResolution:(int) res
{
	NSLog (@"Starting transformation");
	[self setMatrix:A];
	NSLog (@"Just set Matrix");
	[self WXformWithResolution: res];
	return [self matrix];
}


-(void) rowWIXform
{
    int i,j;
    int lenx = [S m_rows];
    int leny = [S m_cols] / 2;
    double sq2 = sqhalf;
	
	for ( i = 0; i < lenx; i++)
		for (j = 0; j < leny; j++)
		{
			[S matrix][i][2 * j] = ([T matrix][i][j ] - [T matrix][i ][j + leny] ) * sq2;
			[S matrix][i][2 * j + 1] = ([T matrix][i][j  ] + [T matrix][i][j + leny] ) * sq2;
		}
}

-(void) colWIXform
{
    int i,j;
    int lenx = [S m_rows]  /2;
    int leny = [S m_cols];
    double sq2 = sqhalf;
	
    
    for ( j = 0; j < leny; j++)
        for (i = 0; i < lenx; i++)
        {
            [T matrix][i * 2  +0][ j ] = ([S matrix][i ][j ] - [S matrix][i + lenx][j] ) * sq2;
            [T matrix][i *2  + 1][j ] = ([S matrix][i ][j ] + [S matrix][i + lenx ][j] ) * sq2;
        }
}



-(BOOL) WIXform
{

    int index;
    
    int length = resolution;
    int i, j;
    for ( index = length ; index >= 0; index--)
    {
        [self colWIXform];
        [self rowWIXform];
    }
    return YES;
}

-(BOOL) WIXformWithResolution: (int) res
{
	resolution = res;
	[self WIXform];
}

-(matrixType *) xiFormMatrix: (matrixType *) A withResolution:(int) res
{
	[self setMatrix:A];
	[self WIXformWithResolution: res];
	return [self matrix];
}

-(void) setMatrix: (matrixType *)A
{
    [S release];
	S = [[matrixType init] alloc];
	[S allocateRows:[A m_rows] columns:[A m_cols]];
    [S copyElements:A];
	[S retain];
	NSLog (@"Setting Matrix");
}

-(matrixType *) matrix
{
    return S;
}


/*


-(BOOL) selfPWIXform: (quadnode *) r
{
		quadnode *temp;
		quadnode tempchild;
		//astack->push(r);
		int index,start;
		
		int length = resolution / 4;
		int i, j;
		
		for ( index = 0; index < length; index = index * 4 +1){ start = index;}
		for ( index = start; index >= 0;  )
		{
			[qtree gotoNode:index];
			[qtree getNode:temp];
			[self colWIXform:temp];
			[self rowWIXform:temp];
			if ( index != 0 ) 
				index = (index)/4;
			else 
				index = -1;
			
		}
		return true;
}

-(void) selfPWXform: (quadnode *) r
{
    quadnode *temp ;//, temp2, a,v,h,d;
    int ai, vi, hi, di;
    int index;
	
    int length = resolution;
    int length4 = resolution/4 ;
    cout << "In Self WX form r "  << length << " " << r.id << "\n";
    int i,j;            
    for ( index = r->myid; index < length4; index = index * 4 +1)
    {
        [qtree gotoNode:index];
        temp = [qtree getNode];;
        [self rowWXform:temp];
        [self colWXform:temp];
        [self getSstats:temp];
    }    
}

*/


@end
