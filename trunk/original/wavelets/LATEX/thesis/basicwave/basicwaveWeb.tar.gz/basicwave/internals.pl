# LaTeX2HTML 99.2beta8 (1.43)
# Associate internals original text with physical files.


$key = q/rightWavepic/;
$ref_files{$key} = "$dir".q|node11.html|; 
$noresave{$key} = "$nosave";

$key = q/rightDan/;
$ref_files{$key} = "$dir".q|node11.html|; 
$noresave{$key} = "$nosave";

$key = q/rightDanRecovered/;
$ref_files{$key} = "$dir".q|node11.html|; 
$noresave{$key} = "$nosave";

$key = q/recover3R001/;
$ref_files{$key} = "$dir".q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/recover3R010/;
$ref_files{$key} = "$dir".q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/wavepic/;
$ref_files{$key} = "$dir".q|node11.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_matrix01/;
$ref_files{$key} = "$dir".q|node52.html|; 
$noresave{$key} = "$nosave";

$key = q/recoverEven/;
$ref_files{$key} = "$dir".q|node10.html|; 
$noresave{$key} = "$nosave";

$key = q/recoverHid/;
$ref_files{$key} = "$dir".q|node12.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_graps/;
$ref_files{$key} = "$dir".q|node52.html|; 
$noresave{$key} = "$nosave";

$key = q/sample/;
$ref_files{$key} = "$dir".q|node10.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_walker/;
$ref_files{$key} = "$dir".q|node52.html|; 
$noresave{$key} = "$nosave";

$key = q/recover3R002/;
$ref_files{$key} = "$dir".q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/recover3R005/;
$ref_files{$key} = "$dir".q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/recoverOdd/;
$ref_files{$key} = "$dir".q|node10.html|; 
$noresave{$key} = "$nosave";

$key = q/wavepicR3/;
$ref_files{$key} = "$dir".q|node12.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_tabor/;
$ref_files{$key} = "$dir".q|node52.html|; 
$noresave{$key} = "$nosave";

1;

