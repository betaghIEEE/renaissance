#include "convolve.hpp"
#include "haarGen.hpp"
#include "plotResults.hpp"
#include <math.h>
#include <iostream.h>
#include "xform.hpp"

double xform::log2 (double t)
{
	return (log(t)/log(2.0));
}

int xform::log2 (int t)
{
	double td = t;
	int r = int (floor (log2 (td)));
	return r;
}

void xform::join (myVector &left, myVector &right, myVector &result)
{
	result.deallocate();
	int sl, sr, s, i;
	sl = left.Size();
	sr = right.Size();
	s = sl + sr;
	result.allocate(s);
	for ( i = 0; i < sl; i++)
		result[i] = left[i];
	for ( i = sl; i < s; i++)
		result[i] = right[i-sl];
}

void xform::evenSplit ( myVector &input, myVector &result)
{
	int size = input.Size();
	int i;
	int l = size/2;
	result.allocate(l);
	for ( i = 0; i < l; i++)
		result[i] = input[i*2];
}

void xform::forceInsert (myVector &source, myVector &result)
{
	int start = 0;
	int l1 = source.Size();
	int ltwo = result.Size();
/*
	int end = l1 + start;
	int i;
	if ( (l1 < ltwo) && (start < end) & (end < ltwo))
		for ( i = start; i < end; i++)
			result[i] = source[i];	

*/
	int i;
	if ( l1 <= ltwo)
	{
		cout << "Copy in progress " << endl;
		for ( i = 0; i < l1; i++)
			result[i]= source[i];
	}
}

void xform::forceInsert (myVector &source, myVector &result, int start)
{
	
	int l1 = source.Size();
	int ltwo = result.Size();
	int end = l1 + start;
	int i;
	if ( (l1 < ltwo) && (start < end) & (end < ltwo))
		for ( i = start; i < end; i++)
			result[i] = source[i-start];
	
}

void xform::extract (myVector &source, myVector &result, int start, int end)
{
	int l1, l2, i, j;
	l1 = source.Size();
	
	if ( (0 < start) && (start < end) && (end < l1))
	{
		//result.deallocate();
		l2 = end - start;
		//result.allocate();
		for ( i = start; i < end; i++)
		{
			j = i - start;
			result[j] = source[i];
		}
	}
		
}

void xform::hWave (myVector &input, myVector &result)
{
	hWave(input, result, 1);
}

void xform::hWaveMax (myVector &input, myVector &result)
{
	int l = input.Size();
	int res = log2(l);
	hWave (input, result, res);
}

void xform::hWave (myVector &input, myVector &result, int resolution)
{
	myVector S;
	myVector Ra, Rd, R, F;
	haarGen haarD;
	haarD.genDiff(HD);
	haarD.genAve(HA);
	plotResults test;
	convolveThis myConvolve;
	int l, ls, i, l_2, p2, end;
	l = ls = input.Size();
	S.allocate(ls);
	test.plotVal("sample.hf", input);
	cout << "Just allocated S at size " << ls << endl;
	result.deallocate();
	result.allocate(ls);
	forceInsert (input, S);
	test.plotVal("sample.cp",S);
	l_2 = log2(l);
	if (resolution < l_2)
		l_2 = resolution;
	for ( i = 0; i < l_2; i++)
	{
		myConvolve.convolve (S, HA, Ra);
		myConvolve.convolve (S, HD, Rd);
		test.plotVal ("haar.R1", Ra, Rd);
		join ( Ra, Rd, R);
		test.plotVal ("haar.J1" , R);
		cout << " Just joined Ra and Rd " << R.Size() << endl;
		evenSplit ( R, F);
		test.plotVal ("haar.F1" , F);
		cout << "Conducted even split" << F.Size() <<endl;
		forceInsert (F, result);
		cout << "Conducted force Insert " << result.Size() << endl;
		p2 = int (floor(pow(2, i + 1)));
		end = int (floor (l / p2));
		S.deallocate();
		S.allocate(end);
		extract ( result, S, 0, end);
		
	}
}
