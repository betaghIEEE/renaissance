#include "myVector.h"
#include "xform2D.hpp"
#include "xform.hpp"

void rowWaveletXform ( matrixType &source, matrixType &result)
{
	int i, j;
	int rLimit, cLimit;
	rLimit = source.m_rows;
	cLimit = source.m_cols;
	myVector S(cLimit);
	myVector R;
	xform wave1D;
	
	for ( i = 0; i < rLimit; i++)
	{
		for ( j = 0; j < cLimit; j++)
			S[j] = source[i][j];
		wave1D.hWave (S,R);
		for (j = 0; j < cLimit; j++)
			result[i][j] = R[j];
			
	}
}

void colWaveletXform ( matrixType &source, matrixType &result)
{

	int i, j, n;
	int rLimit, cLimit;
	rLimit = source.m_rows;
	cLimit = source.m_cols;
	myVector S(cLimit);
	myVector R;
	xform wave1D;
	
	for ( j = 0; j < cLimit; j++)
	{
		n=0;
		for ( i = rLimit; i >= 0; i--)
			S[n++] = source[i][j];
		wave1D.hWave (S,R);
		n = 0;
		for ( i = rLimit; i >= 0; i--)
			result[i][j] = R[n];
			
	}
}

void waveletXform (matrixType &source, matrixType &result)
{
	matrixType rowWave;
	rowWaveletXform (source, rowWave);
	colWaveletXform ( rowWave, result);
}
