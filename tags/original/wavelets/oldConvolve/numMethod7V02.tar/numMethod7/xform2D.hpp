#ifndef __WAVE2DCOMP_H__
#define __WAVE2DCOMP_H__
#include "matrixType.h"
class wave2comp
{
	public:
	void rowWaveletXform ( matrixType &source, matrixType &result);
	void colWaveletXform ( matrixType &source, matrixType &result);
	void waveletXform (matrixType &source, matrixType &result);

};


#endif
