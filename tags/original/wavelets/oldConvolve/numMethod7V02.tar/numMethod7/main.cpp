#include <iostream>
#include "xform.hpp"
#include "haarGen.hpp"
#include "plotResults.hpp"
#include "myVector.h"

int main (int argc, const char * argv[]) {
    // insert code here...
    xform test;
    haarGen haar;
    plotResults out;
    myVector x;
    haar.genSample(128, x);
    
    myVector f;
    
    test.hWave(x, f, 4);
    std::cout << "Hello, World!\n";
	out.plotVal ( "sample.out", x);
    out.plotVal ( "haar.out", f);
    
    return 0;
}
