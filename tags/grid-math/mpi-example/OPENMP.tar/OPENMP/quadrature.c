#include<stdio.h>
#include <omp.h>
#define PI  3.141592653589793238462643 
double f(a)
double a;
{
   return (4.0 / (1.0 + a*a));
}
main(int argc, char *argv[])
{
int  i,n;
double h, pi, sum, x;
# pragma omp parallel private (i,x)
{
for (;;) 
{
 # pragma omp single
{
printf("Enter the number of intervals:(0 quits)");
scanf("%d",&n);
printf("%d \n", n);
}
if (n==0) break;
 # pragma omp single
{
h = 1.0/n; 
sum = 0.0;
}
# pragma omp for reduction (+:sum)
	for(i=1;i<=n;i++) 
	{
	x = h*(i-0.5);
	sum += f(x);
}
# pragma omp single
{
pi =h*sum;
printf("Value of PI is %f \n",pi);
}
}
}
}
