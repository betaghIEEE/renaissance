

class matrixType {
    public double A[];
    public int rows;
    public int cols;
    public int length;
}