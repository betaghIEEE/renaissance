
class testjni 
{

	/*
		Test out the basic wavelet 2-D quad tree library
	*/
	public void main ()
	{
		
	}
}