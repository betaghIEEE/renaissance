package jpackets1;

/**
 * <p>Title: Java Wavelet Packets Libraries</p>
 * <p>Description: Wavelet Packet Libraries </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Texas Tech University</p>
 * @author Daniel Beatty
 * @version 1.0
 */

import org.eso.fits.*;

public class jfitsio {
  public jfitsio() {
  }
  public static void main(String[] args) {
    jfitsio jfitsio1 = new jfitsio();
  }

}
