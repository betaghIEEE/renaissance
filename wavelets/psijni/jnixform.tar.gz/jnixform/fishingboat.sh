./multiply2Dpsin 1 6 pgmclassics/fishingboat.pgm pgmclassics/fishingboat.pgm > fishingboat.results
./multiply2Dpsin 2 6 pgmclassics/fishingboat.pgm pgmclassics/fishingboat.pgm >> fishingboat.results
./multiply2Dpsin 3 6 pgmclassics/fishingboat.pgm pgmclassics/fishingboat.pgm >> fishingboat.results
./multiply2Dpsin 4 6 pgmclassics/fishingboat.pgm pgmclassics/fishingboat.pgm >> fishingboat.results
./multiply2Dpsin 5 6 pgmclassics/fishingboat.pgm pgmclassics/fishingboat.pgm >> fishingboat.results
./multiply2Dpsin 6 6 pgmclassics/fishingboat.pgm pgmclassics/fishingboat.pgm >> fishingboat.results
./multiply2Dpsin 7 6 pgmclassics/fishingboat.pgm pgmclassics/fishingboat.pgm >> fishingboat.results
