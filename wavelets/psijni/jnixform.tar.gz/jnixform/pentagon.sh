./multiply2Dpsin 1 5 pgmclassics/pentagon.pgm pgmclassics/pentagon.pgm > pentagon.results
date >> pentagon.results
./multiply2Dpsin 2 5 pgmclassics/pentagon.pgm pgmclassics/pentagon.pgm >> pentagon.results
date >> pentagon.results
./multiply2Dpsin 3 5 pgmclassics/pentagon.pgm pgmclassics/pentagon.pgm >> pentagon.results
date >> pentagon.results
./multiply2Dpsin 4 5 pgmclassics/pentagon.pgm pgmclassics/pentagon.pgm >> pentagon.results
date >> pentagon.results
./multiply2Dpsin 5 5 pgmclassics/pentagon.pgm pgmclassics/pentagon.pgm >> pentagon.results
date >> pentagon.results
./multiply2Dpsin 6 5 pgmclassics/pentagon.pgm pgmclassics/pentagon.pgm >> pentagon.results
date >> pentagon.results
./multiply2Dpsin 7 5 pgmclassics/pentagon.pgm pgmclassics/pentagon.pgm >> pentagon.results
date >> pentagon.results
