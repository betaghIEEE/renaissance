./multiply2Dpsin 1 6 pgmclassics/peppers.pgm pgmclassics/peppers.pgm > peppers.results
./multiply2Dpsin 2 6 pgmclassics/peppers.pgm pgmclassics/peppers.pgm >> peppers.results
./multiply2Dpsin 3 6 pgmclassics/peppers.pgm pgmclassics/peppers.pgm >> peppers.results
./multiply2Dpsin 4 6 pgmclassics/peppers.pgm pgmclassics/peppers.pgm >> peppers.results
./multiply2Dpsin 5 6 pgmclassics/peppers.pgm pgmclassics/peppers.pgm >> peppers.results
./multiply2Dpsin 6 6 pgmclassics/peppers.pgm pgmclassics/peppers.pgm >> peppers.results
./multiply2Dpsin 7 6 pgmclassics/peppers.pgm pgmclassics/peppers.pgm >> peppers.results
