
#ifndef __MATRIXNODE__
#define __MATRIXNODE__
struct matrixnode {
    int i, j;
    bool sparse;
};

#endif __MATRIXNODE__