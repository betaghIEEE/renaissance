
struct performmeasure 
{
    int totalinstructions;
    int totaldatacompares;
    int totaldatatransfers;
};