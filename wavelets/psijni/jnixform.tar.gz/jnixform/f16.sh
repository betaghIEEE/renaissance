date > f16.results
./multiply2Dpsin 1 4 pgmclassics/f16.pgm pgmclassics/f16.pgm >> f16.results
date >> f16.results
./multiply2Dpsin 2 4 pgmclassics/f16.pgm pgmclassics/f16.pgm >> f16.results
date >> f16.results
./multiply2Dpsin 3 4 pgmclassics/f16.pgm pgmclassics/f16.pgm >> f16.results
date >> f16.results
./multiply2Dpsin 4 4 pgmclassics/f16.pgm pgmclassics/f16.pgm >> f16.results
date >> f16.results
./multiply2Dpsin 5 4 pgmclassics/f16.pgm pgmclassics/f16.pgm >> f16.results
date >> f16.results
./multiply2Dpsin 6 4 pgmclassics/f16.pgm pgmclassics/f16.pgm >> f16.results
date >> f16.results
./multiply2Dpsin 7 4 pgmclassics/f16.pgm pgmclassics/f16.pgm >> f16.results
date >> f16.results
