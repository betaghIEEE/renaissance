#include "xformqtree.hpp"
#include "imageio.hpp"
#include "matrixType.h"
#include <iostream.h>


int main ()
{
	matrixType pic, xpic, rpic;
	xformquadtree xf;
	imageIO pgm;
	pgm.getImagePGM2 ("sandra.ppm" , pic);
        pgm.saveImagePGM2 ("sandra", pic);
        cout << "Before self wx form \n";
	xf.selfWXform (pic, xpic); 
	pgm.saveImagePGM2 ("test", xpic);
        
        xf.selfWIXform (xpic, rpic);
        pgm.saveImagePGM2 ("recover", rpic);
	return 0;
}
